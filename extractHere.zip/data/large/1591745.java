package org.exist.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.exist.external.org.apache.commons.io.output.ByteArrayOutputStream;

public class Compressor {

    /**
     * The method <code>compress</code>
     *
     * @param whatToCompress a <code>byte[]</code> value
     * @return a <code>byte[]</code> value
     * @exception IOException if an error occurs
     */
    public static byte[] compress(byte[] whatToCompress) throws IOException {
        return compress(whatToCompress, whatToCompress.length);
    }

    /**
     * The method <code>compress</code>
     *
     * @param whatToCompress a <code>byte[]</code> value
     * @param length an <code>int</code> value
     * @return a <code>byte[]</code> value
     * @exception IOException if an error occurs
     */
    public static byte[] compress(byte[] whatToCompress, int length) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream gzos = new ZipOutputStream(baos);
        gzos.setMethod(ZipOutputStream.DEFLATED);
        gzos.putNextEntry(new ZipEntry(length + ""));
        gzos.write(whatToCompress, 0, length);
        gzos.closeEntry();
        gzos.finish();
        gzos.close();
        return baos.toByteArray();
    }

    /**
     * The method <code>uncompress</code>
     *
     * @param whatToUncompress a <code>byte[]</code> value
     * @return a <code>byte[]</code> value
     * @exception IOException if an error occurs
     */
    public static byte[] uncompress(byte[] whatToUncompress) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        uncompress(whatToUncompress, baos);
        return baos.toByteArray();
    }

    public static void uncompress(byte[] whatToUncompress, OutputStream os) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(whatToUncompress);
        ZipInputStream gzis = new ZipInputStream(bais);
        ZipEntry zipentry = gzis.getNextEntry();
        Integer.parseInt(zipentry.getName());
        byte[] buf = new byte[512];
        int bread;
        while ((bread = gzis.read(buf)) != -1) os.write(buf, 0, bread);
        gzis.closeEntry();
        gzis.close();
    }
}
